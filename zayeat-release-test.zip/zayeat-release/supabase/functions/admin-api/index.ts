import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import 'jsr:@supabase/functions-js/edge-runtime.d.ts';
const URL=Deno.env.get('SUPABASE_URL')||'', SERVICE=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')||'', ANON=Deno.env.get('SUPABASE_ANON_KEY')||'';
const allowed=(Deno.env.get('SITE_ORIGIN')||'https://mhtiger0903727-ux.github.io').split(',').map(x=>x.trim());
function headers(origin:string|null){const ok=origin&&allowed.includes(origin)?origin:allowed[0];return {'Access-Control-Allow-Origin':ok,'Vary':'Origin','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type, x-bootstrap-secret','Access-Control-Allow-Methods':'POST, OPTIONS','Content-Type':'application/json'};}
function out(body:unknown,status=200,origin:string|null=null){return new Response(JSON.stringify(body),{status,headers:headers(origin)});}
const validUser=(u:string)=>/^[a-z0-9_]{3,32}$/.test(u);
Deno.serve(async(req:Request)=>{
 const origin=req.headers.get('origin'); if(req.method==='OPTIONS')return new Response('ok',{headers:headers(origin)}); if(req.method!=='POST')return out({error:'Method not allowed'},405,origin);
 if(!URL||!SERVICE||!ANON)return out({error:'Server configuration missing'},500,origin);
 const db=createClient(URL,SERVICE,{auth:{persistSession:false}}), auth=createClient(URL,ANON,{auth:{persistSession:false}});
 let b:Record<string,any>;try{b=await req.json()}catch{return out({error:'Invalid JSON'},400,origin)} const action=String(b.action||'');
 try{
  if(action==='bootstrap'){
   const secret=req.headers.get('x-bootstrap-secret')||'', expected=Deno.env.get('BOOTSTRAP_SECRET')||'';
   if(!expected||secret.length<32||secret!==expected)return out({error:'Setup authorization failed'},403,origin);
   const {count,error:ce}=await db.from('admin_users').select('user_id',{count:'exact',head:true});if(ce)return out({error:'Setup state unavailable'},500,origin);if((count||0)>0)return out({error:'Initial setup already completed'},409,origin);
   const username=String(b.username||'').toLowerCase(),email=String(b.email||''),password=String(b.password||'');if(!validUser(username)||password.length<12||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return out({error:'Invalid username, email or password'},400,origin);
   const {data:c,error}=await db.auth.admin.createUser({email,password,email_confirm:true});if(error||!c.user)return out({error:'Could not create owner'},400,origin);
   const {error:ie}=await db.from('admin_users').insert({user_id:c.user.id,username,role:'owner'});if(ie){await db.auth.admin.deleteUser(c.user.id);return out({error:'Owner setup failed; it may already be initialized'},409,origin)}
   await db.from('admin_audit_log').insert({actor:c.user.id,action:'bootstrap_owner',target:username});return out({ok:true},200,origin);
  }
  if(action==='login'){
   const username=String(b.username||'').toLowerCase(),password=String(b.password||'');const {data:r}=await db.from('admin_users').select('user_id,role').eq('username',username).maybeSingle();
   if(!r)return out({error:'نام کاربری یا رمز عبور اشتباه است.'},401,origin);const {data:u}=await db.auth.admin.getUserById(r.user_id);const email=u.user?.email;if(!email)return out({error:'نام کاربری یا رمز عبور اشتباه است.'},401,origin);
   const {data:s,error}=await auth.auth.signInWithPassword({email,password});if(error||!s.session)return out({error:'نام کاربری یا رمز عبور اشتباه است.'},401,origin);
   await db.from('admin_audit_log').insert({actor:r.user_id,action:'login',target:username});return out({access_token:s.session.access_token,refresh_token:s.session.refresh_token,expires_at:s.session.expires_at,role:r.role},200,origin);
  }
  if(action==='public_files'){
   const {data,error}=await db.from('site_files').select('id,original_name,mime_type,caption,price,placement,storage_path').order('created_at',{ascending:false});if(error)throw error;
   const rows=await Promise.all((data||[]).map(async f=>{const {data:s}=await db.storage.from('zayeat-files').createSignedUrl(f.storage_path,1800);const {storage_path,...rest}=f;return {...rest,signed_url:s?.signedUrl||null}}));return out({data:rows},200,origin);
  }
  if(action==='register_customer'){
   const ip=req.headers.get('cf-connecting-ip')||req.headers.get('x-real-ip')||'unknown';const digest=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(ip));const hash=Array.from(new Uint8Array(digest)).map(x=>x.toString(16).padStart(2,'0')).join('');
   const {data:ok,error:le}=await db.rpc('allow_customer_signup',{p_ip_hash:hash});if(le||!ok)return out({error:'تعداد ثبت‌نام از این اتصال بیش از حد مجاز است. بعداً دوباره تلاش کنید.'},429,origin);
   const row={first_name:String(b.first_name||'').trim(),last_name:String(b.last_name||'').trim(),phone:String(b.phone||'').trim(),address:String(b.address||'').trim()};if(Object.values(row).some(x=>!x)||row.first_name.length>100||row.last_name.length>100||row.phone.length>40||row.address.length>500)return out({error:'اطلاعات واردشده معتبر نیست.'},400,origin);
   const {data,error}=await db.from('customers').insert(row).select('file_no').single();if(error)throw error;return out({data},200,origin);
  }
  const bearer=req.headers.get('authorization')||'',token=bearer.startsWith('Bearer ')?bearer.slice(7):'';if(!token)return out({error:'Authentication required'},401,origin);
  const {data:ud,error:ue}=await db.auth.getUser(token);if(ue||!ud.user)return out({error:'Invalid session'},401,origin);const actor=ud.user.id;
  const {data:ar,error:ae}=await db.from('admin_users').select('username,role').eq('user_id',actor).maybeSingle();if(ae||!ar)return out({error:'Administrator access required'},403,origin);
  const ownerOnly=['admin_list','admin_create','admin_delete','admin_set_password'];if(ownerOnly.includes(action)&&ar.role!=='owner')return out({error:'Owner permission required'},403,origin);
  if(action==='whoami')return out({username:ar.username,role:ar.role},200,origin);
  if(action==='list_customers'){const {data,error}=await db.from('customers').select('*').order('created_at',{ascending:false}).limit(2000);if(error)throw error;return out({data},200,origin)}
  if(action==='list_files'){const {data,error}=await db.from('site_files').select('*').order('created_at',{ascending:false});if(error)throw error;const rows=await Promise.all((data||[]).map(async f=>{const {data:s}=await db.storage.from('zayeat-files').createSignedUrl(f.storage_path,1800);return {...f,signed_url:s?.signedUrl||null}}));return out({data:rows},200,origin)}
  if(action==='upload_file'){
   const name=String(b.name||'file').slice(0,180),mime=String(b.mime_type||'application/octet-stream'),caption=String(b.caption||'').trim(),placement=b.placement==='products'?'products':'home',price=String(b.price||'').slice(0,100),base64=String(b.base64||'');
   if(!caption||base64.length>28000000||!/^[\w .()\-\u0600-\u06FF]+$/.test(name))return out({error:'Invalid file data'},400,origin);
   const allowedMime=new Set(['image/jpeg','image/png','image/webp','image/gif','audio/mpeg','audio/mp3','audio/wav','audio/ogg','video/mp4','video/webm','application/pdf','application/octet-stream']);if(!allowedMime.has(mime))return out({error:'File type is not allowed'},415,origin);
   const bytes=Uint8Array.from(atob(base64),c=>c.charCodeAt(0));if(bytes.byteLength>20*1024*1024)return out({error:'File exceeds 20 MB'},413,origin);
   const path=`${crypto.randomUUID()}/${name}`;const {error:up}=await db.storage.from('zayeat-files').upload(path,bytes,{contentType:mime,upsert:false,contentDisposition:'attachment'});if(up)throw up;
   const {data,error}=await db.from('site_files').insert({storage_path:path,original_name:name,mime_type:mime,caption,price,placement}).select().single();if(error){await db.storage.from('zayeat-files').remove([path]);throw error}await db.from('admin_audit_log').insert({actor,action,target:data.id});return out({data:{id:data.id}},200,origin);
  }
  if(action==='update_file'){const patch={caption:String(b.caption||'').trim(),price:String(b.price||'').slice(0,100),placement:b.placement==='products'?'products':'home'};if(!patch.caption)return out({error:'Caption required'},400,origin);const {data,error}=await db.from('site_files').update(patch).eq('id',b.id).select().single();if(error)throw error;await db.from('admin_audit_log').insert({actor,action,target:String(b.id)});return out({data},200,origin)}
  if(action==='delete_file'){const {data:f,error:fe}=await db.from('site_files').select('storage_path').eq('id',b.id).single();if(fe)throw fe;const {error}=await db.from('site_files').delete().eq('id',b.id);if(error)throw error;await db.storage.from('zayeat-files').remove([f.storage_path]);await db.from('admin_audit_log').insert({actor,action,target:String(b.id)});return out({ok:true},200,origin)}
  if(action==='admin_list'){const {data,error}=await db.from('admin_users').select('username,role,created_at').order('created_at');if(error)throw error;return out({data},200,origin)}
  if(action==='admin_create'){const username=String(b.username||'').toLowerCase(),email=String(b.email||''),password=String(b.password||'');if(!validUser(username)||password.length<12||!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return out({error:'Invalid username, email or password'},400,origin);const {data:c,error:ce}=await db.auth.admin.createUser({email,password,email_confirm:true});if(ce||!c.user)return out({error:'Could not create admin'},400,origin);const {error:ie}=await db.from('admin_users').insert({user_id:c.user.id,username,role:'admin',created_by:actor});if(ie){await db.auth.admin.deleteUser(c.user.id);return out({error:'Username already exists or insert failed'},409,origin)}await db.from('admin_audit_log').insert({actor,action,target:username});return out({ok:true},200,origin)}
  if(action==='admin_delete'){const {data:t,error:te}=await db.from('admin_users').select('user_id,username,role').eq('username',String(b.username||'')).single();if(te)throw te;if(t.user_id===actor)return out({error:'Cannot delete your own account here'},400,origin);const {error}=await db.auth.admin.deleteUser(t.user_id);if(error)throw error;await db.from('admin_audit_log').insert({actor,action,target:t.username});return out({ok:true},200,origin)}
  if(action==='admin_set_password'||action==='change_my_password'){const password=String(b.password||'');if(password.length<12)return out({error:'Password must be at least 12 characters'},400,origin);let target=actor;if(action==='admin_set_password'){const {data:t,error:te}=await db.from('admin_users').select('user_id').eq('username',String(b.username||'')).single();if(te)throw te;target=t.user_id;}const {error}=await db.auth.admin.updateUserById(target,{password});if(error)throw error;await db.from('admin_audit_log').insert({actor,action,target:action==='change_my_password'?ar.username:String(b.username)});return out({ok:true},200,origin)}
  return out({error:'Unknown action'},400,origin);
 }catch(e){console.error('admin-api',e);return out({error:'عملیات انجام نشد. تنظیمات سرور یا داده‌ها را بررسی کنید.'},500,origin)}
});
