-- Apply only to a dedicated Supabase development branch/project.
create table if not exists public.admin_users (
 user_id uuid primary key references auth.users(id) on delete cascade,
 username text not null unique,
 role text not null default 'admin' check (role in ('owner','admin')),
 created_at timestamptz not null default now(),
 created_by uuid references auth.users(id) on delete set null,
 constraint admin_username_format check (username=lower(username) and username ~ '^[a-z0-9_]{3,32}$')
);
create unique index if not exists admin_users_single_owner on public.admin_users ((role)) where role='owner';
create table if not exists public.customers (
 id uuid primary key default gen_random_uuid(),
 file_no bigint generated always as identity (start with 1405000),
 first_name text not null check(length(first_name)<=100),
 last_name text not null check(length(last_name)<=100),
 phone text not null check(length(phone)<=40),
 address text not null check(length(address)<=500),
 created_at timestamptz not null default now()
);
create table if not exists public.site_files (
 id uuid primary key default gen_random_uuid(), storage_path text not null unique,
 original_name text not null, mime_type text not null, caption text not null,
 price text, placement text not null check(placement in ('home','products')),
 created_at timestamptz not null default now()
);
create table if not exists public.admin_audit_log (
 id bigint generated always as identity primary key,
 actor uuid references auth.users(id) on delete set null,
 action text not null, target text, created_at timestamptz not null default now()
);
create table if not exists public.customer_signup_limits (
 ip_hash text primary key, window_started timestamptz not null default now(), attempts integer not null default 0
);
create or replace function public.allow_customer_signup(p_ip_hash text)
returns boolean language plpgsql security definer set search_path=pg_catalog,public as $$
declare n integer;
begin
 insert into public.customer_signup_limits(ip_hash,window_started,attempts) values(p_ip_hash,now(),1)
 on conflict(ip_hash) do update set
 window_started=case when public.customer_signup_limits.window_started < now()-interval '1 hour' then now() else public.customer_signup_limits.window_started end,
 attempts=case when public.customer_signup_limits.window_started < now()-interval '1 hour' then 1 else public.customer_signup_limits.attempts+1 end
 returning attempts into n;
 return n<=5;
end; $$;
revoke all on function public.allow_customer_signup(text) from public,anon,authenticated;
grant execute on function public.allow_customer_signup(text) to service_role;
alter table public.admin_users enable row level security;
alter table public.customers enable row level security;
alter table public.site_files enable row level security;
alter table public.admin_audit_log enable row level security;
alter table public.customer_signup_limits enable row level security;
revoke all on public.admin_users,public.customers,public.site_files,public.admin_audit_log,public.customer_signup_limits from anon,authenticated;
grant usage on schema public to anon,authenticated;
insert into storage.buckets(id,name,public,file_size_limit)
values('zayeat-files','zayeat-files',false,20971520)
on conflict(id) do update set public=false,file_size_limit=20971520;
